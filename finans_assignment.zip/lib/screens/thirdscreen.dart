import 'package:finans_assignment/screens/fourthscreen.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class ThirdScreen extends StatefulWidget {
  @override
  _ThirdScreenState createState() => _ThirdScreenState();
}

class _ThirdScreenState extends State<ThirdScreen> {

  String selectedgoal;
  String selectedincome;
  String selectedexp;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create Account'),
        backgroundColor: Colors.blue,
      ),
      body: Container(
        decoration: BoxDecoration(color: Colors.blue),
        child: Column(
          children: [
            SizedBox(
              height: 50,
            ),
            Row(
              children: [
                SizedBox(
                  width: 30,
                ),
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.green,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('1')),
                ),
                Container(width: 30,
                  decoration: BoxDecoration(border: Border.all(width: 1,color: Colors.black)),
                ),
                Container(
                  height: 50,
                  width: 50,

                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.green,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('2')),
                ),
                Container(width: 30,
                  decoration: BoxDecoration(border: Border.all(width: 1,color: Colors.black)),
                ),
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('3')),
                ),
                Container(width: 30,
                  decoration: BoxDecoration(border: Border.all(width: 1,color: Colors.black)),
                ),
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('4')),
                ),
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              child: Column(mainAxisAlignment: MainAxisAlignment.start,crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 20,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 18.0),
                    child: Text("Personal Information",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 16),),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left:18.0),
                    child: Text("Please fill in the information below and your goal for digital saving",style: TextStyle(color: Colors.white,fontSize: 14),),
                  ),

                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    width: double.infinity,
                    margin: EdgeInsets.only(left: 16,right: 16),
                    decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(8)),
                    child:Center(
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton(
                            value: selectedgoal,
                            items: <String>['Goal for Activation', 'A', 'B', 'C'].map((String value) {
                            return new DropdownMenuItem<String>(
                              value: value,
                              child: new Text(value),
                            );
                          }).toList(),
                            onChanged: (values) {
                                setState(() {
                                  selectedgoal=values;
                                });
                            },
                            hint: Text("Choose Option"),
                          ),
                        )),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(width: double.infinity,
                    margin: EdgeInsets.only(left: 16,right: 16),
                    decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(8)),
                    child:Center(
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton(
                            items: <String>['35K-50K', '60K-80K', '1lac-3lac', '5Lac'].map((String values) {
                              return new DropdownMenuItem<String>(
                                value: values,
                                child: new Text(values),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                selectedincome=value;
                              });
                            },
                            hint: Text("Choose Option"),
                            value: selectedincome,
                          ),
                        )),
                  ),

                   SizedBox(
                    height: 20,
                  ),
                  Container(width: double.infinity,
                    margin: EdgeInsets.only(left: 16,right: 16),
                    decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(8)),
                    child:Center(
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton(
                            items: <String>['2K-5K', '10K-50K', '60k ', '80k'].map((String valuess) {
                            return new DropdownMenuItem<String>(
                              value: valuess,
                              child: Text(valuess),
                            );
                          }).toList(),
                            onChanged: (values) {
                            setState(() {
                              selectedexp=values;
                            });
                            },
                            hint: Text("Choose Option"),
                            value: selectedexp,
                           // value: selectedexp,
                          ),
                        )),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(height: 50,
                    margin: EdgeInsets.only(left: 18,right: 18),
                      width: MediaQuery.of(context).size.width,
                      child: FlatButton(height: 50,
                          color: Colors.blue[300],
                          child: Text(
                            "NEXT",
                            style: TextStyle(color: Colors.white),
                          ),
                          onPressed: () {
                        if(selectedgoal != null && selectedincome != null && selectedexp != null) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => FourthScreen()));
                            }
                        else {
                          Fluttertoast.showToast(msg: 'Please Select All Options',textColor: Colors.white,backgroundColor: Colors.black87);
                        }
                          }))
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}