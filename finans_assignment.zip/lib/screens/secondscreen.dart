import 'package:finans_assignment/screens/thirdscreen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SecondScreen extends StatefulWidget {
  @override
  _SecondScreenState createState() => _SecondScreenState();
}

class _SecondScreenState extends State<SecondScreen> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController _passwordcontroller = TextEditingController();
  bool _isLowercasePresent = false;
  bool _isUppercasePresent = false;
  bool _isNumberPresent = false;
  bool _isPwNineChar = false;
  bool _showPassword = false;
  String complexity = '';
  Pattern pattern =
      r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create Account'),
        backgroundColor: Colors.blue,
      ),
      body: Container(
        decoration: BoxDecoration(color: Colors.blue),
        child: Column(
          children: [
            SizedBox(
              height: 20,
            ),
            Row(
              children: [
                SizedBox(
                  width: 30,
                ),
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.green,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('1')),
                ),
                Container(
                  width: 30,
                  decoration: BoxDecoration(
                      border: Border.all(width: 1, color: Colors.black)),
                ),
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('2')),
                ),
                Container(
                  width: 30,
                  decoration: BoxDecoration(
                      border: Border.all(width: 1, color: Colors.black)),
                ),
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('3')),
                ),
                Container(
                  width: 30,
                  decoration: BoxDecoration(
                      border: Border.all(width: 1, color: Colors.black)),
                ),
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('4')),
                ),
              ],
            ),
            SizedBox(
              height: 40,
            ),
            Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 18.0),
                    child: Text(
                      "Create Password",
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 18.0, top: 8),
                    child: Text(
                      "Password will be used to login into account",
                      style: TextStyle(color: Colors.white, fontSize: 13),
                    ),
                  ),
                  SizedBox(
                    height: 40,
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 18, right: 18),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.blue)),
                    child: Form(
                      key: _formKey,
                      child: TextFormField(
                        maxLines: 1,
                        obscureText: !this._showPassword,
                        controller: _passwordcontroller,
                        decoration: InputDecoration(
                          suffixIcon: IconButton(
                            icon: Icon(
                              Icons.remove_red_eye,
                              color: this._showPassword
                                  ? Colors.blue //Color.fromRGBO(47, 20, 153, 1)
                                  : Colors.grey,
                            ),
                            onPressed: (){
                              setState(() => this._showPassword =
                              !this._showPassword);
                            },
                          ),
                          //      labelText: "Password",
                          hintText: 'Password',
                          labelStyle: TextStyle(fontSize: 12),
                          hintStyle: TextStyle(fontSize: 12),
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                            borderSide: BorderSide(width: 0.1),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                            borderSide:
                                BorderSide(width: 1, color: Colors.grey),
                          ),
                        ),
                        validator: (value) {
                          /*Pattern pattern =
                                r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$';
                            */
                          RegExp regex = new RegExp(pattern);
                          if (!regex.hasMatch(value)) {
                            return 'Please Enter Valid Password';
                          }
                          return null;
                        },
                        onChanged: (String value) {
                          print(value);
                          if (value.length < 9) {
                            setState(() {
                              complexity = "Very Weak";
                              print(complexity);
                            });
                            //return 'Password Should be 9 Character' +weak;
                          } else if (value.contains(
                              value.toLowerCase().toUpperCase(), 0)) {
                            setState(() {
                              complexity = "Poor";
                              print(complexity);
                            });
                          } else if (value.contains(pattern) || value.length>9) {
                            setState(() {
                              _isPwNineChar = true;
                              _isNumberPresent = true;
                              _isLowercasePresent = true;
                              _isUppercasePresent = true;
                              complexity = "Excellent";
                              print(complexity);
                            });
                          }

                        },
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 10),
                    child: Row(
                      children: [
                        Text(
                          'Complexity',
                          style: TextStyle(color: Colors.white, fontSize: 14),
                        ),
                        //SizedBox(width: 10,),
                        complexity == null ? Text('') : Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(complexity),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 30),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          children: [
                          _isLowercasePresent == true ?
                          Container(height: 30,width: 30,decoration: BoxDecoration(shape: BoxShape.circle, color:Colors.green,),
                            child: Center(child: Icon(Icons.check,color: Colors.white,)),
                          )
                              :  Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "a",
                                style: TextStyle(
                                    color: Colors.white, fontSize: 24),
                              ),
                            ),
                            Text(
                              "Lowercase",
                              style: TextStyle(color: Colors.white70),
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            _isUppercasePresent == true ?
                            Container(height: 30,width: 30,decoration: BoxDecoration(shape: BoxShape.circle, color:Colors.green,),
                              child: Center(child: Icon(Icons.check,color: Colors.white,)),
                            )
                                : Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "A",
                                style: TextStyle(
                                    color: Colors.white, fontSize: 22),
                              ),
                            ),
                            Text(
                              "Uppercase",
                              style: TextStyle(color: Colors.white70),
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            _isNumberPresent == true ?
                            Container(height: 30,width: 30,decoration: BoxDecoration(shape: BoxShape.circle, color:Colors.green,),
                              child: Center(child: Icon(Icons.check,color: Colors.white,)),
                            )
                                :    Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "123",
                                style: TextStyle(
                                    color: Colors.white, fontSize: 20),
                              ),
                            ),
                            Text(
                              "Number",
                              style: TextStyle(color: Colors.white70),
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            _isPwNineChar == true ?
                            Container(height: 30,width: 30,decoration: BoxDecoration(shape: BoxShape.circle, color:Colors.green,),
                              child: Center(child: Icon(Icons.check,color: Colors.white,)),
                            )
                                :     Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                "9+",
                                style: TextStyle(
                                    color: Colors.white, fontSize: 20),
                              ),
                            ),
                            Text(
                              "Characters",
                              style: TextStyle(color: Colors.white70),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 90,
                  ),
                  Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20)),
                      margin: EdgeInsets.only(left: 12, right: 12),
                      child: FlatButton(
                          minWidth: MediaQuery.of(context).size.width,
                          color: Colors.blue[400],
                          child: Text(
                            "NEXT",
                            style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),
                          ),
                          onPressed: () {
                            if (_formKey.currentState.validate()) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => ThirdScreen()));
                            }
                          }))
                ],
              ),
            ),

          ],
        ),
      ),
    );
  }
}
