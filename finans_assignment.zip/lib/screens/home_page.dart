import 'package:finans_assignment/screens/secondscreen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _formKey = GlobalKey<FormState>();
  bool _isStepComplete = false;
  TextEditingController _emailController = TextEditingController();
  String email;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        alignment: Alignment.topLeft,
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/images/bg.png'),
                fit: BoxFit.fitWidth,
                alignment: Alignment.topLeft)),
        child: Column(
          children: [
            SizedBox(
              height: 50,
            ),
            Row(
              children: [
                SizedBox(
                  width: 30,
                ),
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('1')),
                ),
                Container(width: 30,
                  decoration: BoxDecoration(border: Border.all(width: 1,color: Colors.black)),
                ),
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('2')),
                ),
                Container(width: 30,
                  decoration: BoxDecoration(border: Border.all(width: 1,color: Colors.black)),
                ),
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('3')),
                ),
                Container(width: 30,
                  decoration: BoxDecoration(border: Border.all(width: 1,color: Colors.black)),
                ),
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('4')),
                ),
              ],
            ),
            SizedBox(
              height: 80,
            ),
            Container(
              child: Column(
                children: [
                  Container(
                      alignment: Alignment.topLeft,
                      margin: EdgeInsets.only(left: 18.0),
                      child: Text(
                        "Welcome to",
                        style: TextStyle(
                            fontSize: 30, fontWeight: FontWeight.bold),
                      )),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left:18.0),
                        child: Text(
                          "GIN",
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                      ),
                      Text(
                        " Finans",
                        style: TextStyle(
                            fontSize: 20,color: Colors.indigo ,fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                      margin: EdgeInsets.only(left: 22.0,right: 22),
                      child: Text(
                        "Welcome to The Bank of The Future Manage and track your accounts on the go.",
                        style: TextStyle(
                            fontSize: 16  , fontWeight: FontWeight.bold),
                      )),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 22,right: 22,top: 20),
                    child: Form(key: _formKey,
                      child: TextFormField(controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        maxLines: 1,
                        onSaved: (value){
                          setState(() {
                            email = value;
                          });
                        },
                        onChanged: (v)=>email=v,
                        decoration: InputDecoration(
                          prefixIcon: Icon(Icons.email),
                          labelText: "Email",
                          hintText: 'Email',
                          labelStyle: TextStyle(fontSize: 12),
                          hintStyle: TextStyle(fontSize: 12),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(5.0)),
                            borderSide: BorderSide(width: 0.1),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(5.0)),
                            borderSide: BorderSide(
                                width: 1, color: Colors.grey),
                          ),
                        ),
                        validator: (value) {
                          if (value.trim().isEmpty) {
                            return "Please Enter Email";
                          }else if(value.isNotEmpty){
                            Pattern pattern =
                                r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]"
                                r"{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]"
                                r"{0,253}[a-zA-Z0-9])?)*$";
                            RegExp regex = new RegExp(pattern);
                            if (!regex.hasMatch(value) || value == null){
                              final snackbar = SnackBar(content: Text('Enter a valid email address'),);
                              return 'Enter a valid email address';
                            }
                            return null;
                          }else
                          return null;
                        },//sahi kar iske brackets
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 100,
                  ),
                  Align(alignment: Alignment.bottomCenter,
                    child: Container(alignment: Alignment.bottomCenter,height: 50,
                        margin: EdgeInsets.only(left: 8,right: 8),
                        width: MediaQuery.of(context).size.width,
                        child: FlatButton(minWidth: MediaQuery.of(context).size.width,height: 50,
                            color: Colors.indigoAccent,
                            child: Text(
                              "NEXT",
                              style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 16),
                            ),
                            onPressed: () {
                              print("email $email");
                                if(_formKey.currentState.validate()){
                                  Navigator.push(context, MaterialPageRoute(builder: (context) => SecondScreen()));
                                }else{
                                  }

                            })),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
  String validateEmail(String value) {
    print("Validation called");
    Pattern pattern =
        r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]"
        r"{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]"
        r"{0,253}[a-zA-Z0-9])?)*$";
    RegExp regex = new RegExp(pattern);
    if (!regex.hasMatch(value) || value == null){
      final snackbar = SnackBar(content: Text('Enter a valid email address'),);
      return 'Enter a valid email address';
    }

    else
      return 'Success';
  }
}
/*else{
                            Pattern pattern =
                                r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]"
                                r"{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]"
                                r"{0,253}[a-zA-Z0-9])?)*$";
                            RegExp regex = new RegExp(pattern);
                            if (!regex.hasMatch(value) || value == null){
                              return 'Enter a valid email address';
                            }*/