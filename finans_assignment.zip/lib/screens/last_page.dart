
import 'package:flutter/material.dart';

class LastPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(color: Colors.blue,
        child: Center(
          child:Text("Complete Successfully!",style: TextStyle(fontSize: 22,fontWeight: FontWeight.bold,color: Colors.white),),
        ),
      ),
    );
  }
}
