import 'package:date_time_picker/date_time_picker.dart';
import 'package:finans_assignment/screens/last_page.dart';
import 'package:flutter/material.dart';

class FourthScreen extends StatefulWidget {
  @override
  _FourthScreenState createState() => _FourthScreenState();
}

class _FourthScreenState extends State<FourthScreen> {
  double _height;
  double _width;

  String _setTime, _setDate;

  String _hour, _minute, _time;

  String dateTime;

  DateTime selectedDate = DateTime.now();

  TimeOfDay selectedTime = TimeOfDay(hour: 00, minute: 00);

  TextEditingController _dateController = TextEditingController();
  TextEditingController _timeController = TextEditingController();
  Future<void> _showDateTimePicker()async
  {
    final DateTime datePicked=await showDatePicker(context: context, initialDate: DateTime.now(), firstDate: DateTime(2015, 8), lastDate: DateTime(2101));

    if(datePicked!=null)
    {
      final TimeOfDay timePicked=await showTimePicker(context: context,initialTime: TimeOfDay(hour: TimeOfDay.now().hour,minute: TimeOfDay.now().minute));
      if(timePicked !=null)
      {
      _setDate=DateFormat("yyyy-MM-dd").format(datePicked);
        print("${ DateFormat("yyyy-MM-dd").format(datePicked)}  ${timePicked.format(context)}");
      }
    }

  }
  Future<void> _showTimePicker()async{
    final TimeOfDay picked=await showTimePicker(context: context,initialTime: TimeOfDay(hour: 5,minute: 10));
    if(picked != null)
    {
      _setTime=picked.format(context);
      print(picked.format(context));
    }
  }
  @override
  Widget build(BuildContext context) {
    _height = MediaQuery.of(context).size.height;
    _width = MediaQuery.of(context).size.width;
  //  dateTime = DateFormat.yMd().format(DateTime.now());
    return Scaffold(
      appBar: AppBar(title: Text('Create Account'),),
      body: Container(color: Colors.blue,
        child: Column(
          children: [
            SizedBox(
              height: 30,
            ),
            Row(
              children: [
                SizedBox(
                  width: 30,
                ),
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.green,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('1')),
                ),
                Container(width: 30,
                  decoration: BoxDecoration(border: Border.all(width: 1,color: Colors.black)),
                ),
                Container(
                  height: 50,
                  width: 50,

                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.green,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('2')),
                ),
                Container(width: 30,
                  decoration: BoxDecoration(border: Border.all(width: 1,color: Colors.black)),
                ),
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.green,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('3')),
                ),
                Container(width: 30,
                  decoration: BoxDecoration(border: Border.all(width: 1,color: Colors.black)),
                ),
                Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Center(child: Text('4')),
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Container(margin: EdgeInsets.only(left: 16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(decoration: BoxDecoration(shape: BoxShape.circle,color: Colors.white),
                      child: IconButton(icon: Icon(Icons.calendar_today_outlined,color: Colors.blue,), onPressed: () {})),
                  SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text("Schedule Video Call",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 16),),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                        "Choose the date and time that you prefered, we will send a link via email to make a video call on the Schedule  date and time.",style: TextStyle(color: Colors.white),),
                  ),
                  Container(
                    child: Center(
                      child: Column(
                        children: [
                          Text(
                            'Choose Date',
                            style: TextStyle(
                                fontStyle: FontStyle.italic,
                                fontWeight: FontWeight.w600,
                                letterSpacing: 0.5),
                          ),
                          Container(decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(8)),
                            margin: EdgeInsets.only(left: 10,right: 10),
                            child: Row(
                              children: [
                              Expanded(
                                child: Container(padding: EdgeInsets.only(left: 20),
                                  child:   _setDate==null?Text('Choose date'):Text(_setDate),
                                ),
                              ),
                                IconButton(icon: Icon(Icons.calendar_today,size: 30,), onPressed: (){_showDateTimePicker();})
                              ],
                            ),
                          ),
                          Text(
                            'Choose Time',
                            style: TextStyle(
                                fontStyle: FontStyle.italic,
                                fontWeight: FontWeight.w600,
                                letterSpacing: 0.5),
                          ),
                        Container(decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(8)),
                          margin: EdgeInsets.only(left: 10,right: 10),
                          child: Row(
                            children: [
                             Expanded(
                               child: Container(padding: EdgeInsets.only(left: 20),
                                 child:  _setTime==null?Text('Select Time'):Text(_setTime),
                               ),
                             ),
                              IconButton(icon: Icon(Icons.timer_outlined,size: 30,), onPressed: (){
                                _showTimePicker();
                              })
                            ],
                          ),
                        )


                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                      width: MediaQuery.of(context).size.width,
                      margin: EdgeInsets.only(left: 10,right: 10),
                      child: RaisedButton(
                          color: Colors.blue[400],
                          child: Text(
                            "NEXT",
                            style: TextStyle(color: Colors.white),
                          ),
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) => LastPage()));
                          }))
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
